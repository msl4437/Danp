#!/bin/sh
rm -f $0
passwd=Admin$RANDOM
if [ ! -z "$PASSWD" ];then 
    passwd=$PASSWD
fi
echo "当前ROOT密码为$passwd"
echo "root:$passwd"|chpasswd

if [ -z "$domain" ];then 
    echo "domain变量不存在"
    exit
else
    echo "当前域名为$domain"
    cp -rf /usr/local/apache/conf/lnmpa-apache-vhost-example.conf /usr/local/apache/conf/vhost/$domain.conf
    cp -rf /usr/local/nginx/conf/lnmpa-nginx-vhost-example.conf /usr/local/nginx/conf/vhost/$domain.conf
    sed -i "s/{domain}/$domain/g" /usr/local/apache/conf/vhost/$domain.conf
    sed -i "s/{Amail}/$Amail/g" /usr/local/apache/conf/vhost/$domain.conf
    sed -i "s/{Amail}/$Amail/g" /usr/local/apache/conf/httpd.conf
	sed -i "s/{Amail}/$Amail/g" /usr/local/apache/conf/extra/httpd-vhosts.conf
    sed -i "s/{domain}/$domain/g" /usr/local/nginx/conf/vhost/$domain.conf
    if [ ! -d "/home/wwwroot/$domain" ];then
        mkdir -p /home/wwwroot/$domain
    fi
    if [ ! -d "/home/wwwlogs" ];then
        mkdir -p /home/wwwlogs
    fi
    if [ ! -d "/home/www" ];then
        mkdir -p /home/www
    fi
    chown -R www:www /home
    chmod -R 0755 /home
fi

if [ -z "$domains" ];then 
    domains=''
fi

sed -i "s/{domains}/$domains/g" /usr/local/apache/conf/vhost/$domain.conf
sed -i "s/{domains}/$domains/g" /usr/local/nginx/conf/vhost/$domain.conf    

$@
/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf
/usr/local/apache/bin/httpd -k start
/usr/sbin/sshd -D
